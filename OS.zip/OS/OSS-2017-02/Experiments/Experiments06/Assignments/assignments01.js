// Please implements multiplication tables (구구단)

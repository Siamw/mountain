var numbers = new Array(12, 45, 2, 31, 4, 56, 6, 7);

// find out maximum number and minimum numbers

for (var index in numbers) {
  console.log ("index[" + index +"] = " + numbers[index]);
}

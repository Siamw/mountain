var numbers = new Array (10, 11, 2, 1, 3, 1, 4, 10, 20, 21);

// Sort numbers in ascending order

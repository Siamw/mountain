var a = 10;
var b = "String";
result = (typeof b == "string" ? "B is String" : "B is Numeric");
console.log("Result => ");
console.log(result);
result = (typeof a == "string" ? "A is String" : "A is Numeric");
console.log("Result => ");
console.log(result);

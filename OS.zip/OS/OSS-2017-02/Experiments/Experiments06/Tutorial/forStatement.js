var numbers = new Array(1,2,2,3,4)
for (var num in numbers) {
  // key and Value
  console.log(num + "  =  " + numbers[num]);;
}
console.log ("Exiting from the loop!");

var a = 2; // Bit presentation 10
var b = 3; // Bit presentation 11
console.log("(a & b) => ");
result = (a & b);
console.log(result);

console.log("(a | b) => ");
result = (a | b);
console.log(result);

console.log("(a ^ b) => ");
result = (a ^ b);
console.log(result);

console.log("(~b) => ");
result = (~b);
console.log(result);

console.log("(a << b) => ");
result = (a << b);
console.log(result);

console.log("(a >> b) => ");
result = (a >> b);
console.log(result);

var a = 10;
var b = 20;
var linebreak = "<br />";
console.log ("((a > b) ? 100 : 200) => ");
result = (a > b) ? 100 : 200;
console.log(result);
console.log ("((a < b) ? 100 : 200) => ");

result = (a < b) ? 100 : 200;
console.log(result);

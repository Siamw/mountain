var count = 0;
console.log("Starting Loop ");

while (count < 10) {
  console.log("Current Count : " + count);
  count++;
}
console.log("Loop stopped!");


var count = 0;
console.log("Starting Loop");
do {
  console.log("Current Count : " + count);
  count++;
} while (count < 5);
console.log ("Loop stopped!");

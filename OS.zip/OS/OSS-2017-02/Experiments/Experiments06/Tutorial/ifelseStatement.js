var age = 20;
if( age > 18 ) {
  console.log("Qualifies for driving");
}

var age = 15;
if( age > 18 ) {
  console.log("Qualifies for driving");
} else {
  console.log("Does not qualify for driving");
}


var book = "maths";
if( book == "history" ) {
  console.log("History Book");
} else if( book == "maths" ) {
  console.log("Maths Book");
} else if( book == "economics" ) {
  console.log("Economics Book");
} else {
  console.log("Unknown Book");
}

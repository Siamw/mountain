var test = new Array(1,2,3,4,5,6);

for (var aa in test) {
	console.log(aa); // Set breakpoint here
}

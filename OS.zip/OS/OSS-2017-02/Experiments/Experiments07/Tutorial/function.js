function concatenate(first, last)
{
	    var full;
	    full = first + last;
	     return full;
}
function secondFunction()
{
	    var result;
	    result = concatenate('Zara', 'Ali');
	    console.log (result );
}
secondFunction();

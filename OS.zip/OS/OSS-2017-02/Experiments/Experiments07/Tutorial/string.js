var val = new String("test");

console.log(val.charAt(1));
console.log(val.charCodeAt(1));
console.log(val.concat("aaa"));
console.log(val.indexOf("st"));
console.log(val.indexOf("t"));
console.log(val.lastIndexOf("t"));
console.log(val.replace("te","a"));
console.log(val.slice(2));
console.log(val.split("es"));
console.log(val.substr(2,2));

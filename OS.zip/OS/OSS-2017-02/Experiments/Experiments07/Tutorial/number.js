var val = new Number(100.000);

console.log(val.toExponential());
console.log(val.toFixed());
console.log(val.toLocaleString());
console.log(val.toPrecision());
console.log(val.toString());

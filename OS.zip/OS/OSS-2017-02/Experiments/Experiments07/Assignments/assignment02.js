function slice(str, start, end) {

}
var str = "Apples are round, and apples are juicy.";
var sliced = str.slice(1, 3);
console.log( sliced );
console.log( slice(str, 1, 3));

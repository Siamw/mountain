function reverse (input) {

}
var arr = [0, 1, 2, 3];
console.log ("Reversed array is : " + arr.reverse() );
console.log ("Reversed array is : " + reverse(arr));

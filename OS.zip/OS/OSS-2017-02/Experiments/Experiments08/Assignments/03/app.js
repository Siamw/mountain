var fs = require("fs");
var searchString = "test";

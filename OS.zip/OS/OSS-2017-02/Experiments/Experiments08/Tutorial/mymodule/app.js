
var dt = require('./mymodule');

console.log(dt.myDateTime());
